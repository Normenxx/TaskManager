class App
{
  public static void main(String[] args)
  {
    Kommandozeilenmenue menue = new Kommandozeilenmenue();
    menue.start();
  }
}
